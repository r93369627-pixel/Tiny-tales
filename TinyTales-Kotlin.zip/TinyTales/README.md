# Tiny Tales (Kotlin + Jetpack Compose)

Tiny Tales ka native Android version. Saari images, music aur stories app ke andar (assets) hain, internet nahi chahiye.

## APK banane ke steps (laptop par)
1. Android Studio (latest) install karo.
2. File > Open > is `TinyTales` folder ko chuno. Pehli baar Gradle sync me kuch minute lagte hain (internet chahiye).
3. Testing APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
   File milegi: `app/build/outputs/apk/debug/app-debug.apk`
4. Play Store ke liye: Build > Generate Signed Bundle / APK > Android App Bundle (.aab).
   Signing key (keystore) sambhal ke rakhna, updates ke liye zaroori hai.

## Isme kya hai
Splash, naam + buddy chunna, Home (daily goal, surprise, story of the day), Story library (categories),
story padhna (Hindi/English, phone ki awaaz se read-aloud), quiz, stars, badges, animals + animal quiz,
Memory game, Alphabet, Numbers, Settings (language, music, voice speed, text size), Parents gate.

## Web version se jo abhi nahi hai
Draw and colour, Character maker, voice recording, mic se jawab dena, sleep timer, word highlight,
colour themes / dark mode, favourites, cartoon section, recorded MP3 voices (audio/ folder).

## Dhyan do
- Ye code maine bina compile kiye likha hai. Pehli build me chhoti errors aa sakti hain; error text mujhe bhej do, main theek kar dunga.
- Hindi awaaz ke liye phone me Google Text-to-Speech me Hindi voice installed honi chahiye.
- Images/music ka licence proof rakho, Play Store maang sakta hai.

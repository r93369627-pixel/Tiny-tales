package com.tinytales.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AColor
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Ink = Color(0xFF3A2A12)
val Mute = Color(0xFF7A6544)
val Sun = Color(0xFFFFB300)
val Org = Color(0xFFFF7A1A)
val SkyBlue = Color(0xFF4CB8F5)
val Ok = Color(0xFF2E9E5B)
val Bad = Color(0xFFE5484D)
val BgTop = Color(0xFFCDEFFF)
val BgBottom = Color(0xFFFFF3C4)

val LocalFs = compositionLocalOf { 1f }

fun hex(s: String): Color = try { Color(AColor.parseColor(s)) } catch (_: Exception) { Color.White }

private val bitmapCache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
    override fun sizeOf(key: String, value: Bitmap) = value.byteCount
}

@Composable
fun AssetImage(
    path: String,
    modifier: Modifier = Modifier,
    scale: ContentScale = ContentScale.Fit,
    bg: Color = Color.Transparent,
) {
    val ctx = LocalContext.current
    val bmp = remember(path) {
        bitmapCache.get(path) ?: try {
            ctx.assets.open(path).use { BitmapFactory.decodeStream(it) }?.also { bitmapCache.put(path, it) }
        } catch (_: Exception) { null }
    }
    Box(modifier.background(bg)) {
        if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = scale)
    }
}

/** A picture in a rounded square with its own background colour (like the web version). */
@Composable
fun Pic(path: String, size: Dp, bg: String = "#ffffff", emoji: String = "") {
    if (path.isNotEmpty()) {
        AssetImage(path, Modifier.size(size).clip(RoundedCornerShape(18.dp)), ContentScale.Fit, hex(bg))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(18.dp)).background(Color.White), Alignment.Center) {
            Text(emoji, fontSize = (size.value * 0.55f).sp)
        }
    }
}

@Composable
fun Txt(
    s: String, size: Int = 18, bold: Boolean = false, color: Color = Ink,
    align: TextAlign = TextAlign.Start, modifier: Modifier = Modifier,
) {
    Text(
        s, modifier = modifier, color = color, textAlign = align,
        fontSize = (size * LocalFs.current).sp,
        lineHeight = (size * LocalFs.current * 1.35f).sp,
        fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.Medium,
    )
}

@Composable
fun ScreenBox(scroll: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BgTop, BgBottom)))) {
        val m = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)
        Column(if (scroll) m.verticalScroll(rememberScrollState()) else m, content = content)
    }
}

@Composable
fun StarChip(n: Int) {
    Row(
        Modifier.clip(RoundedCornerShape(99.dp)).background(Sun).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AssetImage("img/ic_3.png", Modifier.size(24.dp))
        Spacer(Modifier.width(6.dp))
        Txt("$n", 20, true)
    }
}

@Composable
fun TopBar(title: String, stars: Int, onBack: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            Btn("← Back", onBack, small = true, ghost = true)
            Spacer(Modifier.width(10.dp))
        }
        Txt(title, 24, true, Org, modifier = Modifier.weight(1f))
        StarChip(stars)
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(24.dp))
            .background(Color.White).padding(16.dp),
        content = content,
    )
}

@Composable
fun Btn(
    label: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    small: Boolean = false, ghost: Boolean = false, alt: Boolean = false, size: Int = 0,
) {
    val bg = when { ghost -> Color.White; alt -> SkyBlue; else -> Org }
    Box(
        modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = if (small) 14.dp else 20.dp, vertical = if (small) 6.dp else 12.dp),
        Alignment.Center,
    ) {
        Txt(label, if (size > 0) size else if (small) 17 else 20, true, if (ghost) Ink else Color.White, TextAlign.Center)
    }
}

/** Big picture tile with a caption, used on Home, Games and Animals. */
@Composable
fun Tile(
    label: String, modifier: Modifier = Modifier, selected: Boolean = false, onClick: () -> Unit,
    pic: @Composable () -> Unit,
) {
    Column(
        modifier.clip(RoundedCornerShape(22.dp)).background(if (selected) Sun else Color.White)
            .border(3.dp, if (selected) Org else Color.Transparent, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        pic()
        Spacer(Modifier.height(4.dp))
        Txt(label, 16, true, align = TextAlign.Center)
    }
}

@Composable
fun Grid(cols: Int, count: Int, item: @Composable (Int, Modifier) -> Unit) {
    var start = 0
    while (start < count) {
        val end = minOf(start + cols, count)
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            for (i in start until end) item(i, Modifier.weight(1f))
            repeat(cols - (end - start)) { Spacer(Modifier.weight(1f)) }
        }
        start = end
    }
}

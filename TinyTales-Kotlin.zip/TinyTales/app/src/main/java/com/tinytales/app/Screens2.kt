package com.tinytales.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AnimalPic(a: Animal, size: androidx.compose.ui.unit.Dp) = Pic(a.img, size, a.bg, a.emoji)

@Composable
fun AnimalsScreen(app: AppCtl) {
    val s = app.store
    val list = app.content.animals
    ScreenBox {
        TopBar(app.t("जानवरों की दुनिया", "Animal World"), s.stars) { app.back() }
        Txt(app.t("किसी जानवर को छुओ!", "Tap an animal to meet it!"), 18, color = Mute, modifier = Modifier.padding(bottom = 10.dp))
        Grid(3, list.size) { i, m ->
            val a = list[i]
            Tile(a.name(s.lang), m, onClick = { app.go(Dest.AnimalD(a.key)) }) { AnimalPic(a, 72.dp) }
        }
        Btn(app.t("जानवर क्विज़", "Animal quiz"), { app.go(Dest.AnimalQuiz) }, Modifier.fillMaxWidth(), alt = true)
    }
}

@Composable
fun AnimalScreen(app: AppCtl, key: String) {
    val s = app.store
    val a = app.content.animals.first { it.key == key }
    LaunchedEffect(key) { app.say(a.sound) }
    ScreenBox {
        TopBar(a.name(s.lang), s.stars) { app.speaker.stop(); app.back() }
        Box(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(24.dp)).background(hex(a.bg))
                .clickable { app.say(a.sound) }.padding(18.dp),
            Alignment.Center,
        ) { AnimalPic(a, 230.dp) }
        Card {
            Txt("${a.name(s.lang)} ${app.t("कहता है", "says")} “${a.sound}”", 21, true)
            Spacer(Modifier.height(6.dp))
            Txt(a.fact(s.lang), 22)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("🔊 ${app.t("आवाज़", "Sound")}", { app.say(a.sound) }, Modifier.weight(1f), alt = true)
            Btn("🔊 ${app.t("जानकारी", "Fact")}", { app.say(a.fact(s.lang)) }, Modifier.weight(1f), ghost = true)
        }
        Spacer(Modifier.height(10.dp))
        Btn(app.t("📖 कहानियाँ", "📖 Stories"), { app.go(Dest.Library(animal = key)) }, Modifier.fillMaxWidth())
    }
}

@Composable
fun AnimalQuizScreen(app: AppCtl) {
    val s = app.store
    val all = app.content.animals
    val total = 5
    var round by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    val order = remember { all.shuffled().take(total) }
    var picked by remember(round) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    if (round >= total) {
        ScreenBox {
            TopBar(app.t("जानवर क्विज़", "Animal quiz"), s.stars) { app.back() }
            Card {
                Txt(app.t("तुम्हारे $score / $total सही!", "You got $score / $total right!"), 26, true, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Btn(app.t("फिर से खेलो", "Play again"), { app.replace(Dest.AnimalQuiz) }, Modifier.fillMaxWidth())
        }
        return
    }
    val right = order[round]
    val opts = remember(round) { (all.filter { it.key != right.key }.shuffled().take(2) + right).shuffled() }
    LaunchedEffect(round) { app.say(app.t("कौन कहता है ${right.sound}?", "Who says ${right.sound}?")) }
    ScreenBox {
        TopBar(app.t("जानवर क्विज़", "Animal quiz") + " ${round + 1}/$total", s.stars) { app.speaker.stop(); app.back() }
        Card {
            Txt(app.t("कौन कहता है", "Who says") + " “${right.sound}”?", 26, true)
            Spacer(Modifier.height(6.dp))
            Btn("🔊", { app.say(right.sound) }, small = true, alt = true)
        }
        Grid(3, opts.size) { i, m ->
            val o = opts[i]
            val chosen = picked == o.key
            Column(
                m.clip(RoundedCornerShape(22.dp))
                    .background(if (chosen && o.key == right.key) Ok else if (chosen) Bad else Color.White)
                    .clickable(enabled = picked == null) {
                        picked = o.key
                        if (o.key == right.key) {
                            score++; s.addStars(1); app.sfx.good()
                            app.say(app.t("शाबाश!", "Great job!"))
                        } else {
                            app.sfx.bad()
                            app.say(app.t("यह ${right.nameHi} है।", "It is the ${right.nameEn}."))
                        }
                        scope.launch { delay(1600); round++ }
                    }.padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AnimalPic(o, 80.dp)
                Txt(o.name(s.lang), 15, true, align = TextAlign.Center)
            }
        }
    }
}

@Composable
fun GamesScreen(app: AppCtl) {
    val s = app.store
    ScreenBox {
        TopBar(app.t("खेल और सीखना", "Games and learning"), s.stars) { app.back() }
        Grid(2, 4) { i, m ->
            when (i) {
                0 -> Tile("Memory", m, onClick = { app.go(Dest.Memory) }) { Pic("img/fr_0.jpg", 80.dp, "#fee4c9") }
                1 -> Tile("Alphabet", m, onClick = { app.go(Dest.Alphabet) }) { Pic("img/al_00.jpg", 80.dp, "#ffd5d5") }
                2 -> Tile("Numbers", m, onClick = { app.go(Dest.Numbers) }) { AssetImage("img/ic_5.png", Modifier.size(80.dp)) }
                else -> Tile("Animal quiz", m, onClick = { app.go(Dest.AnimalQuiz) }) { Pic("img/tl_0.jpg", 80.dp, "#a2daff") }
            }
        }
    }
}

@Composable
fun MemoryScreen(app: AppCtl) {
    val s = app.store
    val fruits = app.content.fruits
    var cards by remember { mutableStateOf((fruits.indices + fruits.indices).shuffled()) }
    var matched by remember { mutableStateOf(setOf<Int>()) }
    var open by remember { mutableStateOf(listOf<Int>()) }
    var moves by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val won = matched.size == cards.size
    LaunchedEffect(won) {
        if (won) { s.addStars(3); app.sfx.good(); app.say(app.t("शाबाश! सब जोड़े मिल गए।", "Well done! You found all the pairs.")) }
    }
    ScreenBox {
        TopBar("Memory match", s.stars) { app.back() }
        Txt(app.t("एक जैसे फल ढूँढो", "Find the matching fruit pairs") + "  •  $moves", 18, color = Mute, modifier = Modifier.padding(bottom = 10.dp))
        Grid(4, cards.size) { i, m ->
            val f = fruits[cards[i]]
            val show = i in matched || i in open
            Box(
                m.aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                    .background(if (show) hex(f.bg) else SkyBlue)
                    .clickable(enabled = !show && open.size < 2 && !won) {
                        open = open + i
                        if (open.size == 2) {
                            moves++
                            val (a, b) = open
                            if (cards[a] == cards[b]) {
                                matched = matched + a + b; open = emptyList(); app.sfx.good()
                            } else {
                                scope.launch { delay(800); open = emptyList() }
                            }
                        }
                    },
                Alignment.Center,
            ) {
                if (show) AssetImage(f.img, Modifier.fillMaxSize().padding(4.dp)) else Txt("?", 36, true, Color.White)
            }
        }
        if (won) {
            Card {
                Txt(app.t("🎉 जीत गए! +3 ⭐", "🎉 You won! +3 ⭐"), 24, true, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Btn(app.t("फिर से", "Play again"), {
                cards = (fruits.indices + fruits.indices).shuffled(); matched = emptySet(); open = emptyList(); moves = 0
            }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun AlphabetScreen(app: AppCtl) {
    val s = app.store
    val letters = app.content.letters
    var i by rememberSaveable { mutableIntStateOf(0) }
    val l = letters[i]
    val ch = ('A' + i)
    fun speak() { app.speaker.speak("$ch for ${l.word}", "e", s.rate, s.pitch); s.addWord("al:$i") }
    LaunchedEffect(i) { if (s.voice) speak() }
    ScreenBox {
        TopBar(app.t("वर्णमाला", "Alphabet"), s.stars) { app.speaker.stop(); app.back() }
        Box(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(24.dp)).background(hex(l.bg))
                .clickable { if (s.voice) speak() }.padding(16.dp),
            Alignment.Center,
        ) { Pic(l.img, 220.dp, l.bg, l.emoji) }
        Card {
            Txt("$ch ${ch.lowercaseChar()}", 56, true, Org, TextAlign.Center, Modifier.fillMaxWidth())
            Txt("$ch for ${l.word} ${l.emoji}", 28, true, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("←", { if (i > 0) i-- else i = letters.lastIndex }, Modifier.weight(1f), ghost = true)
            Btn("🔊", { if (s.voice) speak() }, Modifier.weight(1f), alt = true)
            Btn("→", { if (i < letters.lastIndex) i++ else i = 0 }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Btn("1 2 3  Numbers", { app.replace(Dest.Numbers) }, Modifier.fillMaxWidth(), ghost = true)
    }
}

@Composable
fun NumbersScreen(app: AppCtl) {
    val s = app.store
    val nums = app.content.numbers
    var n by rememberSaveable { mutableIntStateOf(1) }
    LaunchedEffect(n) { if (s.voice) app.speaker.speak(nums[n - 1], "e", s.rate, s.pitch) }
    ScreenBox {
        TopBar(app.t("गिनती", "Numbers"), s.stars) { app.speaker.stop(); app.back() }
        Card {
            Txt("$n", 90, true, Org, TextAlign.Center, Modifier.fillMaxWidth())
            Txt(nums[n - 1], 30, true, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Txt("⭐".repeat(n), 34, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        Grid(5, nums.size) { i, m ->
            Box(
                m.aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(if (n == i + 1) Sun else Color.White)
                    .clickable { n = i + 1; s.addWord("num:${i + 1}") },
                Alignment.Center,
            ) { Txt("${i + 1}", 26, true) }
        }
        Spacer(Modifier.height(6.dp))
        Btn("A B C  Alphabet", { app.replace(Dest.Alphabet) }, Modifier.fillMaxWidth(), ghost = true)
    }
}

@Composable
private fun SwitchRow(label: String, on: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, 19, modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = change)
    }
}

@Composable
fun SettingsScreen(app: AppCtl) {
    val s = app.store
    var confirm by remember { mutableStateOf(false) }
    ScreenBox {
        TopBar(app.t("सेटिंग्स", "Settings"), s.stars) { s.save(); app.back() }
        Card {
            Txt(app.t("भाषा", "Language"), 21, true)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("हिन्दी", { s.lang = "h"; s.save() }, Modifier.weight(1f), ghost = s.lang != "h")
                Btn("English", { s.lang = "e"; s.save() }, Modifier.weight(1f), ghost = s.lang != "e")
            }
        }
        Card {
            SwitchRow(app.t("संगीत", "Music"), s.music) { s.music = it; s.save() }
            Txt(app.t("संगीत की आवाज़", "Music volume"), 16, color = Mute)
            Slider(value = s.musicVol, onValueChange = { s.musicVol = it; app.music.setVolume(it) }, onValueChangeFinished = { s.save() })
            SwitchRow(app.t("साउंड इफ़ेक्ट", "Sound effects"), s.sfx) { s.sfx = it; s.save() }
        }
        Card {
            SwitchRow(app.t("आवाज़ में पढ़ना", "Read aloud"), s.voice) { s.voice = it; s.save() }
            SwitchRow(app.t("कहानी अपने आप पढ़ो", "Auto-read stories"), s.autoRead) { s.autoRead = it; s.save() }
            Txt(app.t("बोलने की गति", "Speech speed") + "  ${"%.2f".format(s.rate)}", 16, color = Mute)
            Slider(value = s.rate, onValueChange = { s.rate = it }, valueRange = 0.5f..1.2f, onValueChangeFinished = { s.save() })
            Btn(app.t("आवाज़ टेस्ट करो", "Test voice"), {
                app.say(app.t("नमस्ते! मैं तुम्हारा दोस्त हूँ।", "Hello! I am your friend."))
            }, small = true, alt = true)
        }
        Card {
            Txt(app.t("अक्षर का आकार", "Text size"), 21, true)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("s" to "Small", "m" to "Medium", "l" to "Large").forEach { (k, n) ->
                    Btn(n, { s.fontSize = k; s.save() }, Modifier.weight(1f), small = true, ghost = s.fontSize != k)
                }
            }
        }
        Card {
            Txt(app.t("आपका नाम और दोस्त", "Name and buddy"), 21, true)
            Spacer(Modifier.height(6.dp))
            Btn(app.t("बदलो", "Change"), { app.go(Dest.Welcome) }, small = true, alt = true)
            Spacer(Modifier.height(10.dp))
            Btn(app.t("सारा डेटा मिटाओ", "Erase all data"), { confirm = true }, small = true)
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Erase all data?") },
            text = { Text("This removes the name, stars, badges and progress.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false; app.music.pause(); s.resetAll()
                    app.stack.clear(); app.stack.add(Dest.Welcome)
                }) { Text("Erase") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}

@Composable
fun GateScreen(app: AppCtl, next: Dest) {
    val s = app.store
    val a = remember { (3..9).random() }
    val b = remember { (3..9).random() }
    val answer = a * b
    val opts = remember { (listOf(answer, answer + 3, answer - 4, answer + 7).shuffled()) }
    var wrong by remember { mutableStateOf(false) }
    ScreenBox {
        TopBar(app.t("पेरेंट्स के लिए", "For parents"), s.stars) { app.back() }
        Card {
            Txt(app.t("बड़ों के लिए: हल करो", "Grown-ups only: solve this"), 20, true)
            Spacer(Modifier.height(8.dp))
            Txt("$a × $b = ?", 40, true, Org, TextAlign.Center, Modifier.fillMaxWidth())
            if (wrong) Txt(app.t("फिर से कोशिश करो", "Try again"), 18, color = Bad, modifier = Modifier.padding(top = 6.dp))
        }
        Grid(2, opts.size) { i, m ->
            Box(
                m.clip(RoundedCornerShape(20.dp)).background(Color.White).clickable {
                    if (opts[i] == answer) app.replace(next) else wrong = true
                }.padding(16.dp),
                Alignment.Center,
            ) { Txt("${opts[i]}", 28, true) }
        }
    }
}

@Composable
fun ParentsScreen(app: AppCtl) {
    val s = app.store
    ScreenBox {
        TopBar(app.t("पेरेंट्स", "Parents"), s.stars) { app.back() }
        Card {
            Txt(s.name.ifBlank { "Child" }, 24, true)
            Spacer(Modifier.height(6.dp))
            Txt("⭐ ${s.stars}   📖 ${s.done.size} / ${app.content.stories.size}   🔤 ${s.words.size}   🔥 ${s.streak}", 20)
        }
        Card {
            Txt(app.t("रोज़ की कहानियों का लक्ष्य", "Daily story goal"), 21, true)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..5).forEach { g -> Btn("$g", { s.goal = g; s.save() }, Modifier.weight(1f), small = true, ghost = s.goal != g) }
            }
        }
        Btn(app.t("सेटिंग्स", "Settings"), { app.go(Dest.Settings) }, Modifier.fillMaxWidth(), alt = true)
    }
}

@Composable
fun BadgesScreen(app: AppCtl) {
    val s = app.store
    val rules = s.badgeRules
    val icons = listOf("img/ic_0.png", "img/ic_3.png", "img/ic_8.png", "img/ic_5.png", "img/ic_1.png")
    ScreenBox {
        TopBar(app.t("बैज", "Badges") + " (${s.badges.size} / ${rules.size})", s.stars) { app.back() }
        Grid(3, rules.size) { i, m ->
            val (key, label, _) = rules[i]
            val got = key in s.badges
            Column(
                m.clip(RoundedCornerShape(22.dp)).background(Color.White).padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AssetImage(icons[i], Modifier.size(64.dp).alpha(if (got) 1f else 0.35f))
                Txt(if (got) label else "🔒 $label", 15, true, align = TextAlign.Center)
            }
        }
    }
}

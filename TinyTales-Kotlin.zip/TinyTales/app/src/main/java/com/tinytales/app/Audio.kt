package com.tinytales.app

import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Reads text aloud with the phone's own Hindi / English voice. */
class Speaker(ctx: Context) {
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status -> ready = status == TextToSpeech.SUCCESS }
    }

    fun speak(text: String, lang: String, rate: Float, pitch: Float) {
        val t = tts ?: return
        if (!ready) return
        val loc = if (lang == "h") Locale("hi", "IN") else Locale("en", "IN")
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(if (lang == "h") Locale("hi") else Locale.US)
        }
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tt")
    }

    fun stop() { try { tts?.stop() } catch (_: Exception) {} }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
    }
}

/** Looping background music from assets/music/bg.mp3. */
class Music(private val ctx: Context) {
    private var mp: MediaPlayer? = null

    fun start(volume: Float) {
        try {
            if (mp == null) {
                val afd = ctx.assets.openFd("music/bg.mp3")
                mp = MediaPlayer().apply {
                    setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                    isLooping = true
                    prepare()
                }
            }
            mp?.setVolume(volume, volume)
            if (mp?.isPlaying == false) mp?.start()
        } catch (_: Exception) {}
    }

    fun setVolume(v: Float) { try { mp?.setVolume(v, v) } catch (_: Exception) {} }
    fun pause() { try { if (mp?.isPlaying == true) mp?.pause() } catch (_: Exception) {} }
    fun release() { try { mp?.release() } catch (_: Exception) {}; mp = null }
}

/** Short happy / sad beeps. */
class Sfx {
    private val gen: ToneGenerator? = try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (_: Exception) { null }
    fun good() { try { gen?.startTone(ToneGenerator.TONE_PROP_ACK, 250) } catch (_: Exception) {} }
    fun bad() { try { gen?.startTone(ToneGenerator.TONE_PROP_NACK, 250) } catch (_: Exception) {} }
    fun release() { try { gen?.release() } catch (_: Exception) {} }
}

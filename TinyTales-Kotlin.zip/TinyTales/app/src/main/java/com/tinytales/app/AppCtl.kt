package com.tinytales.app

import android.content.Context
import androidx.compose.runtime.mutableStateListOf

sealed interface Dest {
    data object Splash : Dest
    data object Welcome : Dest
    data object Home : Dest
    data class Library(val cat: String = "", val animal: String = "") : Dest
    data class StoryD(val id: Int) : Dest
    data class Quiz(val id: Int) : Dest
    data class Done(val id: Int, val got: Int) : Dest
    data object Animals : Dest
    data class AnimalD(val key: String) : Dest
    data object AnimalQuiz : Dest
    data object Games : Dest
    data object Memory : Dest
    data object Alphabet : Dest
    data object Numbers : Dest
    data object Settings : Dest
    data object Badges : Dest
    data class Gate(val next: Dest) : Dest
    data object Parents : Dest
}

/** Holds the app's services and the screen stack. */
class AppCtl(ctx: Context) {
    val store = Store(ctx)
    val content = loadContent(ctx)
    val speaker = Speaker(ctx)
    val music = Music(ctx)
    val sfx = Sfx()

    val stack = mutableStateListOf<Dest>(Dest.Splash)
    val cur: Dest get() = stack.last()

    fun go(d: Dest) { stack.add(d) }
    fun replace(d: Dest) { stack[stack.lastIndex] = d }
    fun back() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    fun toHome() { stack.clear(); stack.add(Dest.Home) }

    fun say(text: String) {
        if (store.voice) speaker.speak(text, store.lang, store.rate, store.pitch)
    }

    fun hindi() = store.lang == "h"
    fun t(hi: String, en: String) = if (store.lang == "h") hi else en

    fun release() { speaker.shutdown(); music.release(); sfx.release() }
}

package com.tinytales.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect

class MainActivity : ComponentActivity() {
    private lateinit var app: AppCtl

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        app = AppCtl(this)
        setContent {
            val s = app.store
            LaunchedEffect(s.music, s.musicVol) {
                if (s.music) app.music.start(s.musicVol) else app.music.pause()
            }
            BackHandler(enabled = app.stack.size > 1) {
                app.speaker.stop()
                app.back()
            }
            CompositionLocalProvider(LocalFs provides s.fs) {
                Root(app)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (app.store.music) app.music.start(app.store.musicVol)
    }

    override fun onStop() {
        super.onStop()
        app.music.pause()
        app.speaker.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        app.release()
    }
}

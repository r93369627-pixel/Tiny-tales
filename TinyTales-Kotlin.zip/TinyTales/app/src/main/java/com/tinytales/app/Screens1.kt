package com.tinytales.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun Cover(s: Story, size: androidx.compose.ui.unit.Dp) = Pic(s.cover, size, s.coverBg, s.emoji)

@Composable
fun SplashScreen(app: AppCtl) {
    LaunchedEffect(Unit) {
        delay(1800)
        app.replace(if (app.store.name.isBlank()) Dest.Welcome else Dest.Home)
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF1D8FE8))) {
        AssetImage("img/loading.jpg", Modifier.fillMaxSize(), ContentScale.Crop)
        Column(
            Modifier.fillMaxSize().statusBarsPadding().padding(top = 60.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Txt("Tiny Tales", 46, true, Sun, TextAlign.Center)
            Txt("Listen, speak and learn", 16, true, Color.White, TextAlign.Center)
        }
    }
}

@Composable
fun WelcomeScreen(app: AppCtl) {
    val s = app.store
    var name by remember { mutableStateOf(s.name) }
    var buddy by remember { mutableIntStateOf(s.buddy) }
    val b = app.content.buddies[buddy]
    ScreenBox {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Pic(b.img, 120.dp, "#ffffff")
            Spacer(Modifier.height(8.dp))
            Txt("Hi! I am ${b.name}. What is your name?", 22, true, align = TextAlign.Center)
        }
        Spacer(Modifier.height(12.dp))
        Card {
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(20) }, singleLine = true,
                label = { Txt("Type your name", 16) }, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(10.dp))
            Txt("Choose your buddy", 18, true)
            Spacer(Modifier.height(8.dp))
            Grid(4, app.content.buddies.size) { i, m ->
                val bd = app.content.buddies[i]
                Box(
                    m.aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                        .border(3.dp, if (i == buddy) Org else Color.Transparent, RoundedCornerShape(16.dp))
                        .clickable { buddy = i },
                ) { AssetImage(bd.img, Modifier.fillMaxSize().padding(3.dp), ContentScale.Fit, Color.White) }
            }
        }
        Btn("Let's go!", {
            val n = name.trim()
            if (n.isNotEmpty()) {
                s.name = n; s.buddy = buddy; s.save()
                app.say(app.t("नमस्ते $n!", "Hello $n!"))
                app.toHome()
            }
        }, Modifier.fillMaxWidth(), size = 26)
    }
}

@Composable
fun HomeScreen(app: AppCtl) {
    val s = app.store
    val c = app.content
    val b = c.buddies[s.buddy]
    val goalPct = (s.todayStories.toFloat() / s.goal).coerceAtMost(1f)
    val dayIdx = LocalDate.now().let { it.year * 372 + it.monthValue * 31 + it.dayOfMonth }
    val sotd = c.stories[dayIdx % c.stories.size]
    ScreenBox {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Txt("Tiny Tales", 28, true, Org, modifier = Modifier.weight(1f))
            StarChip(s.stars)
        }
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Pic(b.img, 120.dp, "#ffffff")
            Spacer(Modifier.height(6.dp))
            Box(Modifier.clip(RoundedCornerShape(22.dp)).background(Color.White).padding(horizontal = 18.dp, vertical = 10.dp)) {
                Txt(app.t("नमस्ते ${s.name}! कहानी सुनें?", "Hi ${s.name}! Ready for an adventure?"), 20, true, align = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(12.dp))
        Btn(app.t("▶ कहानी शुरू करो", "▶ Play"), { app.go(Dest.Library()) }, Modifier.fillMaxWidth(), size = 30)
        Spacer(Modifier.height(12.dp))

        Card {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt(app.t("आज का लक्ष्य", "Today's goal"), 19, modifier = Modifier.weight(1f))
                Txt("${minOf(s.todayStories, s.goal)} / ${s.goal}", 19, true)
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(12.dp).clip(CircleShape).background(Color(0x24000000))) {
                Box(Modifier.fillMaxWidth(goalPct).fillMaxHeight().clip(CircleShape).background(Ok))
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AssetImage("img/ic_1.png", Modifier.size(22.dp))
                Spacer(Modifier.width(6.dp))
                Txt(app.t("${s.streak} दिन लगातार", "${s.streak}-day streak"), 16, color = Mute)
            }
        }

        Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AssetImage("img/ic_2.png", Modifier.size(30.dp))
                Spacer(Modifier.width(8.dp))
                Txt(app.t("रोज़ का सरप्राइज़", "Daily surprise"), 21, true)
            }
            Spacer(Modifier.height(8.dp))
            if (s.surpriseReady) {
                Btn(app.t("खोलो (+2 ⭐)", "Open it (+2 ⭐)"), {
                    s.surpriseOpened()
                    app.sfx.good()
                    app.say(app.t("बधाई हो! दो सितारे मिले।", "Hooray! You got two stars."))
                }, Modifier.fillMaxWidth())
            } else {
                Txt(app.t("कल नया सरप्राइज़ मिलेगा!", "Come back tomorrow for a new surprise!"), 16, color = Mute)
            }
        }

        Card {
            Txt(app.t("आज की कहानी", "Story of the day"), 21, true)
            Spacer(Modifier.height(8.dp))
            MiniRow(app, listOf(sotd))
        }
        if (s.hist.isNotEmpty()) Card {
            Txt(app.t("हाल ही में", "Recently played"), 21, true)
            Spacer(Modifier.height(8.dp))
            MiniRow(app, s.hist.mapNotNull { c.stories.getOrNull(it) })
        }

        Grid(3, 6) { i, m ->
            when (i) {
                0 -> Tile(app.t("जानवर", "Animals"), m, onClick = { app.go(Dest.Animals) }) { Pic("img/tl_0.jpg", 64.dp, "#a2daff") }
                1 -> Tile(app.t("कहानियाँ", "Library"), m, onClick = { app.go(Dest.Library()) }) { Pic("img/tl_2.jpg", 64.dp, "#ffffff") }
                2 -> Tile(app.t("खेल", "Games"), m, onClick = { app.go(Dest.Games) }) { Pic("img/tl_3.jpg", 64.dp, "#66feff") }
                3 -> Tile(app.t("शब्द", "Words"), m, onClick = { app.go(Dest.Alphabet) }) { AssetImage("img/ic_8.png", Modifier.size(64.dp)) }
                4 -> Tile(app.t("बैज", "Badges"), m, onClick = { app.go(Dest.Badges) }) { Pic("img/tl_5.jpg", 64.dp, "#ffffff") }
                else -> Tile(app.t("पेरेंट्स", "Parents"), m, onClick = { app.go(Dest.Gate(Dest.Parents)) }) { Pic("img/tl_6.jpg", 64.dp, "#ffffff") }
            }
        }
        Btn(app.t("⚙ सेटिंग्स", "⚙ Settings"), { app.go(Dest.Settings) }, Modifier.fillMaxWidth(), ghost = true)
    }
}

@Composable
fun MiniRow(app: AppCtl, list: List<Story>) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        list.forEach { st ->
            Column(
                Modifier.width(120.dp).clip(RoundedCornerShape(18.dp)).background(BgBottom)
                    .clickable { app.go(Dest.StoryD(st.id)) }.padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Cover(st, 80.dp)
                Spacer(Modifier.height(4.dp))
                Txt(st.text(app.store.lang).title, 14, true, align = TextAlign.Center)
            }
        }
    }
}

@Composable
fun LibraryScreen(app: AppCtl, d: Dest.Library) {
    val s = app.store
    var cat by remember { mutableStateOf(d.cat) }
    val shown = app.content.stories.filter { (cat.isEmpty() || cat in it.cats) && (d.animal.isEmpty() || it.animal == d.animal) }
    ScreenBox {
        TopBar(app.t("कहानियाँ", "Story library"), s.stars) { app.back() }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("All", { cat = "" }, small = true, ghost = cat.isNotEmpty())
            app.content.cats.forEach { ct ->
                Btn("${ct.emoji} ${ct.name}", { cat = ct.key }, small = true, ghost = cat != ct.key)
            }
        }
        if (d.animal.isNotEmpty()) {
            val a = app.content.animals.firstOrNull { it.key == d.animal }
            if (a != null) Txt("Showing ${a.name(s.lang)} stories", 16, color = Mute, modifier = Modifier.padding(bottom = 8.dp))
        }
        if (shown.isEmpty()) {
            Card { Txt("Stories coming soon!", 24) }
        } else {
            Grid(2, shown.size) { i, m ->
                val st = shown[i]
                Column(
                    m.clip(RoundedCornerShape(24.dp)).background(Color.White)
                        .clickable { app.go(Dest.StoryD(st.id)) }.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box { Cover(st, 130.dp); if (st.id in s.done) Txt("✅", 22, modifier = Modifier.align(Alignment.TopEnd)) }
                    Spacer(Modifier.height(4.dp))
                    Txt(st.text(s.lang).title, 17, true, align = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
fun StoryScreen(app: AppCtl, id: Int) {
    val s = app.store
    val st = app.content.stories[id]
    val tx = st.text(s.lang)
    var page by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(id) { s.opened(id) }
    LaunchedEffect(page, s.lang) { if (s.autoRead) app.say(tx.pages[page]) }
    ScreenBox {
        TopBar(tx.title, s.stars) { app.speaker.stop(); app.back() }
        Box(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(24.dp))
                .background(Color(0xFFBFE8FF)).padding(vertical = 18.dp),
            Alignment.Center,
        ) { Txt(st.scenes.getOrElse(page) { st.emoji }, 84, align = TextAlign.Center) }
        Card { Txt(tx.pages[page], 26) }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
            tx.pages.indices.forEach { i ->
                Box(Modifier.padding(3.dp).size(if (i == page) 16.dp else 12.dp).clip(CircleShape).background(if (i == page) Org else Mute.copy(alpha = .35f)))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("🔊", { app.say(tx.pages[page]) }, Modifier.weight(1f), alt = true)
            Btn("←", { if (page > 0) page-- }, Modifier.weight(1f), ghost = true)
            Btn(if (page < tx.pages.lastIndex) "→" else app.t("सवाल ▶", "Quiz ▶"), {
                if (page < tx.pages.lastIndex) page++ else { app.speaker.stop(); app.replace(Dest.Quiz(id)) }
            }, Modifier.weight(2f))
        }
    }
}

@Composable
fun QuizScreen(app: AppCtl, id: Int) {
    val s = app.store
    val tx = app.content.stories[id].text(s.lang)
    var qi by rememberSaveable { mutableIntStateOf(0) }
    var got by rememberSaveable { mutableIntStateOf(0) }
    var chosen by remember(qi) { mutableStateOf<String?>(null) }
    val q = tx.qs[qi]
    val opts = remember(qi, s.lang) { q.opts.shuffled() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(qi) { app.say(q.q) }
    ScreenBox {
        TopBar(app.t("सवाल ${qi + 1} / ${tx.qs.size}", "Question ${qi + 1} / ${tx.qs.size}"), s.stars) { app.speaker.stop(); app.back() }
        Card {
            Txt(q.q, 26, true)
            Spacer(Modifier.height(6.dp))
            Btn("🔊", { app.say(q.q) }, small = true, alt = true)
        }
        opts.forEach { o ->
            val good = chosen == o && o == q.opts[0]
            val wrong = chosen == o && o != q.opts[0]
            Box(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(20.dp))
                    .background(if (good) Ok else Color.White)
                    .border(3.dp, if (wrong) Bad else Color.Transparent, RoundedCornerShape(20.dp))
                    .clickable(enabled = chosen == null || wrong) {
                        chosen = o
                        if (o == q.opts[0]) {
                            app.sfx.good()
                            s.addStars(1); s.addWord("$id:$qi"); got++
                            app.say(app.t("शाबाश! ", "Great job! ") + o)
                            scope.launch {
                                delay(1500)
                                if (qi + 1 < tx.qs.size) qi++ else app.replace(Dest.Done(id, got))
                            }
                        } else {
                            app.sfx.bad()
                            app.say(app.t("कोई बात नहीं, फिर से सोचो।", "No worries, try again."))
                        }
                    }.padding(14.dp),
                Alignment.Center,
            ) { Txt(o, 26, true, if (good) Color.White else Ink, TextAlign.Center) }
        }
    }
}

@Composable
fun DoneScreen(app: AppCtl, d: Dest.Done) {
    val s = app.store
    LaunchedEffect(Unit) {
        s.finishedStory(d.id)
        app.say(app.t("वाह! कहानी पूरी हुई।", "Wow! Story finished."))
    }
    ScreenBox {
        Column(Modifier.fillMaxWidth().padding(top = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AssetImage("img/ic_0.png", Modifier.size(120.dp))
            Spacer(Modifier.height(10.dp))
            Txt(app.t("शाबाश ${s.name}!", "Well done ${s.name}!"), 30, true, Org, TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Txt(app.t("तुमने ${d.got} सितारे कमाए", "You earned ${d.got} stars"), 22, align = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Btn(app.t("और कहानियाँ", "More stories"), { app.stack.clear(); app.stack.add(Dest.Home); app.go(Dest.Library()) }, Modifier.fillMaxWidth(), size = 24)
            Spacer(Modifier.height(10.dp))
            Btn(app.t("होम", "Home"), { app.toHome() }, Modifier.fillMaxWidth(), ghost = true)
        }
    }
}

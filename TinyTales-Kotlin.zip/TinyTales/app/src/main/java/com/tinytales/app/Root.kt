package com.tinytales.app

import androidx.compose.runtime.Composable

@Composable
fun Root(app: AppCtl) {
    when (val d = app.cur) {
        Dest.Splash -> SplashScreen(app)
        Dest.Welcome -> WelcomeScreen(app)
        Dest.Home -> HomeScreen(app)
        is Dest.Library -> LibraryScreen(app, d)
        is Dest.StoryD -> StoryScreen(app, d.id)
        is Dest.Quiz -> QuizScreen(app, d.id)
        is Dest.Done -> DoneScreen(app, d)
        Dest.Animals -> AnimalsScreen(app)
        is Dest.AnimalD -> AnimalScreen(app, d.key)
        Dest.AnimalQuiz -> AnimalQuizScreen(app)
        Dest.Games -> GamesScreen(app)
        Dest.Memory -> MemoryScreen(app)
        Dest.Alphabet -> AlphabetScreen(app)
        Dest.Numbers -> NumbersScreen(app)
        Dest.Settings -> SettingsScreen(app)
        Dest.Badges -> BadgesScreen(app)
        is Dest.Gate -> GateScreen(app, d.next)
        Dest.Parents -> ParentsScreen(app)
    }
}

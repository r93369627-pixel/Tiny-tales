package com.tinytales.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate

/** Everything the child has done. Saved in SharedPreferences. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("tiny_tales", Context.MODE_PRIVATE)

    var name by mutableStateOf(sp.getString("name", "") ?: "")
    var buddy by mutableStateOf(sp.getInt("buddy", 0))
    var stars by mutableStateOf(sp.getInt("stars", 0))
    var lang by mutableStateOf(sp.getString("lang", "h") ?: "h")          // "h" Hindi, "e" English
    var music by mutableStateOf(sp.getBoolean("music", false))
    var musicVol by mutableStateOf(sp.getFloat("musicVol", 0.6f))
    var sfx by mutableStateOf(sp.getBoolean("sfx", true))
    var voice by mutableStateOf(sp.getBoolean("voice", true))
    var autoRead by mutableStateOf(sp.getBoolean("autoRead", true))
    var rate by mutableStateOf(sp.getFloat("rate", 0.85f))
    var pitch by mutableStateOf(sp.getFloat("pitch", 1.1f))
    var fontSize by mutableStateOf(sp.getString("fontSize", "m") ?: "m")  // s m l
    var goal by mutableStateOf(sp.getInt("goal", 1))
    var streak by mutableStateOf(sp.getInt("streak", 0))
    private var lastDay by mutableStateOf(sp.getString("lastDay", "") ?: "")
    private var todayDay by mutableStateOf(sp.getString("todayDay", "") ?: "")
    private var todayCount by mutableStateOf(sp.getInt("todayCount", 0))
    var surpriseDay by mutableStateOf(sp.getString("surpriseDay", "") ?: "")
    var done by mutableStateOf(sp.getString("done", "")!!.split(",").filter { it.isNotBlank() }.map { it.toInt() }.toSet())
    var words by mutableStateOf(sp.getString("words", "")!!.split(",").filter { it.isNotBlank() }.toSet())
    var hist by mutableStateOf(sp.getString("hist", "")!!.split(",").filter { it.isNotBlank() }.map { it.toInt() })
    var badges by mutableStateOf(sp.getString("badges", "")!!.split(",").filter { it.isNotBlank() }.toSet())

    val fs: Float get() = when (fontSize) { "s" -> 0.85f; "l" -> 1.2f; else -> 1f }
    private fun today() = LocalDate.now().toString()
    val todayStories: Int get() = if (todayDay == today()) todayCount else 0

    fun save() {
        sp.edit()
            .putString("name", name).putInt("buddy", buddy).putInt("stars", stars)
            .putString("lang", lang).putBoolean("music", music).putFloat("musicVol", musicVol)
            .putBoolean("sfx", sfx).putBoolean("voice", voice).putBoolean("autoRead", autoRead)
            .putFloat("rate", rate).putFloat("pitch", pitch).putString("fontSize", fontSize)
            .putInt("goal", goal).putInt("streak", streak).putString("lastDay", lastDay)
            .putString("todayDay", todayDay).putInt("todayCount", todayCount)
            .putString("surpriseDay", surpriseDay)
            .putString("done", done.joinToString(","))
            .putString("words", words.joinToString(","))
            .putString("hist", hist.joinToString(","))
            .putString("badges", badges.joinToString(","))
            .apply()
    }

    fun addStars(n: Int) { stars += n; refreshBadges(); save() }

    fun addWord(key: String) { if (key !in words) { words = words + key; refreshBadges(); save() } }

    fun opened(id: Int) { hist = (listOf(id) + hist.filter { it != id }).take(8); save() }

    fun finishedStory(id: Int) {
        done = done + id
        val t = today()
        if (todayDay != t) { todayDay = t; todayCount = 0 }
        todayCount += 1
        if (lastDay != t) {
            val yesterday = LocalDate.now().minusDays(1).toString()
            streak = if (lastDay == yesterday) streak + 1 else 1
            lastDay = t
        }
        refreshBadges(); save()
    }

    fun surpriseOpened() { surpriseDay = today(); addStars(2) }
    val surpriseReady: Boolean get() = surpriseDay != today()

    /** Badge rules, in the same order as the list shown on the Badges screen. */
    val badgeRules: List<Triple<String, String, () -> Boolean>> = listOf(
        Triple("first", "First story", { done.size >= 1 }),
        Triple("s10", "10 stars", { stars >= 10 }),
        Triple("w10", "10 words", { words.size >= 10 }),
        Triple("st5", "5 stories", { done.size >= 5 }),
        Triple("streak3", "3-day streak", { streak >= 3 }),
    )

    private fun refreshBadges() {
        badges = badges + badgeRules.filter { it.third() }.map { it.first }
    }

    fun resetAll() {
        sp.edit().clear().apply()
        name = ""; buddy = 0; stars = 0; lang = "h"; music = false; musicVol = 0.6f
        sfx = true; voice = true; autoRead = true; rate = 0.85f; pitch = 1.1f
        fontSize = "m"; goal = 1; streak = 0; lastDay = ""; todayDay = ""; todayCount = 0
        surpriseDay = ""; done = emptySet(); words = emptySet(); hist = emptyList(); badges = emptySet()
    }
}

package com.tinytales.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Question(val q: String, val opts: List<String>) // opts[0] is the correct answer

class StoryText(val title: String, val pages: List<String>, val qs: List<Question>)

class Story(
    val id: Int,
    val emoji: String,
    val scenes: List<String>,
    val cats: List<String>,
    val animal: String,
    val cover: String,
    val coverBg: String,
    private val hi: StoryText,
    private val en: StoryText,
) {
    fun text(lang: String) = if (lang == "h") hi else en
}

class Animal(
    val key: String, val img: String, val bg: String, val emoji: String,
    val nameHi: String, val nameEn: String, val sound: String,
    val factHi: String, val factEn: String,
) {
    fun name(lang: String) = if (lang == "h") nameHi else nameEn
    fun fact(lang: String) = if (lang == "h") factHi else factEn
}

class Buddy(val name: String, val img: String)
class Cat(val key: String, val emoji: String, val name: String)
class Letter(val word: String, val emoji: String, val img: String, val bg: String)
class Fruit(val name: String, val img: String, val bg: String)

class Content(
    val stories: List<Story>,
    val animals: List<Animal>,
    val buddies: List<Buddy>,
    val cats: List<Cat>,
    val letters: List<Letter>,
    val numbers: List<String>,
    val fruits: List<Fruit>,
)

private fun Context.readAsset(path: String): String =
    assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }

private fun JSONArray.strings(): List<String> = List(length()) { getString(it) }

private fun parseText(o: JSONObject): StoryText {
    val qsArr = o.getJSONArray("q")
    val qs = List(qsArr.length()) {
        val pair = qsArr.getJSONArray(it)
        Question(pair.getString(0), pair.getJSONArray(1).strings())
    }
    return StoryText(o.getString("t"), o.getJSONArray("p").strings(), qs)
}

fun loadContent(ctx: Context): Content {
    val sArr = JSONArray(ctx.readAsset("data/stories.json"))
    val stories = List(sArr.length()) { i ->
        val o = sArr.getJSONObject(i)
        Story(
            id = i,
            emoji = o.getString("e"),
            scenes = o.getJSONArray("s").strings(),
            cats = o.getJSONArray("cats").strings(),
            animal = o.optString("animal", ""),
            cover = o.optString("cover", ""),
            coverBg = o.optString("coverBg", "#ffffff"),
            hi = parseText(o.getJSONObject("h")),
            en = parseText(o.getJSONObject("n")),
        )
    }
    val aArr = JSONArray(ctx.readAsset("data/animals.json"))
    val animals = List(aArr.length()) {
        val o = aArr.getJSONObject(it)
        val n = o.getJSONArray("n"); val f = o.getJSONArray("f")
        Animal(
            o.getString("k"), o.optString("i", ""), o.optString("bg", "#ffffff"), o.optString("e", ""),
            n.getString(0), n.getString(1), o.getString("s"), f.getString(0), f.getString(1),
        )
    }
    val m = JSONObject(ctx.readAsset("data/misc.json"))
    val bu = m.getJSONArray("buddies")
    val ca = m.getJSONArray("cats")
    val le = m.getJSONArray("letters")
    val fr = m.getJSONArray("fruits")
    return Content(
        stories, animals,
        List(bu.length()) { Buddy(bu.getJSONObject(it).getString("n"), bu.getJSONObject(it).getString("i")) },
        List(ca.length()) { val a = ca.getJSONArray(it); Cat(a.getString(0), a.getString(1), a.getString(2)) },
        List(le.length()) { val o = le.getJSONObject(it); Letter(o.getString("w"), o.getString("e"), o.getString("i"), o.getString("bg")) },
        m.getJSONArray("numbers").strings(),
        List(fr.length()) { val o = fr.getJSONObject(it); Fruit(o.getString("n"), o.getString("i"), o.getString("bg")) },
    )
}
